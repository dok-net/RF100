/**
 * bq Prusa i3 Hephestos – Arduino Mega with RAMPS v1.3/1.4 pin assignments
 */

#include "pins_RAMPS_13.h"

#undef FAN_PIN
#define FAN_PIN             9 // (Sprinter config)

#undef HEATER_1_PIN
#define HEATER_1_PIN       -1
